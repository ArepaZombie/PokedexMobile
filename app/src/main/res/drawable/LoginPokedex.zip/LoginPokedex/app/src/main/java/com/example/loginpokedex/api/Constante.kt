package com.example.api.api

class Constante {
    companion object {
        val ruta_base: String = "https://pokeapi.co/api/v2/"
    }
}
