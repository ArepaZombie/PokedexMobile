package com.example.loginpokedex.entidades

data class Sprites(
  var front_default:String
)
