package com.example.loginpokedex.entidades

data class Estadistica(
  var base_stat:Int,
  var name:String
)
