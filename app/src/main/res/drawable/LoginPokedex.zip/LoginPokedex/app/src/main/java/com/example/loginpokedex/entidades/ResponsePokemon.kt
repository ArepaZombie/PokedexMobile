package com.example.loginpokedex.entidades

data class ResponsePokemon (
  var results: List<Pokemon>
)
